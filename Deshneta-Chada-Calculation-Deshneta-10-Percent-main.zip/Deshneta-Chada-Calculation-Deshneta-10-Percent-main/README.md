# Deshneta-Chada-Calculation-Deshneta-10-Percent-
দেশনেতার চাঁদা ক্যালকুলেটর, deshneta, deshneta10percent, deshneta chada calculation

-- Code Collection, i don't know who created this script,i just upload this script in my id

clone by "https://deshneta10percent.vercel.app/"

-this is the fun project, enjoy



## 📸 Screenshots
<img width="270" alt="Screenshot.jpg" src="https://github.com/SiamMia94/Deshneta-Chada-Calculation-Deshneta-10-Percent-/blob/ccb5462480909806e27103f64a24e7633f6f8989/Screenshot_20250713_004855.jpg">

<img width="270" alt="Screenshot.jpg" src="https://github.com/SiamMia94/Deshneta-Chada-Calculation-Deshneta-10-Percent-/blob/ccb5462480909806e27103f64a24e7633f6f8989/Screenshot_2025_0713_005827.jpg">

